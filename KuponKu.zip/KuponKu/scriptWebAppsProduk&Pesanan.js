/** ==========================

CONFIG

========================== */
const SHEET_PRODUK = "Produk";    // Sheet daftar produk
const SHEET_PESANAN = "Pesanan";  // Sheet daftar pesanan
const FOLDER_ID = "1Uslm4QRYC07r2wA1VYAMMgDKW66SI6hV"; // Folder Drive untuk simpan bukti


/** ==========================

GET REQUEST HANDLER

========================== */
function doGet(e) {
  const action = e?.parameter?.action || "";

  if (action === "approveKuponku" && e?.parameter?.row) {
    return approvePesanan(parseInt(e.parameter.row, 10));
  }

  // Default: kirim daftar produk dalam format JSON
  const dataProduk = getProduk();
  return ContentService.createTextOutput(JSON.stringify(dataProduk))
    .setMimeType(ContentService.MimeType.JSON);
}

/** ==========================

POST REQUEST HANDLER

========================== */
function doPost(e) {
  try {
    const data = e.parameter;
    const buktiBase64 = data.bukti;
    let buktiUrl = "";

    // Simpan bukti pembayaran ke Google Drive
    if (buktiBase64) {
      const blob = Utilities.newBlob(Utilities.base64Decode(buktiBase64), "image/jpeg", "bukti.jpg");
      const folder = DriveApp.getFolderById(FOLDER_ID);
      const file = folder.createFile(blob);
      file.setSharing(DriveApp.Access.ANYONE_WITH_LINK, DriveApp.Permission.VIEW);
      buktiUrl = file.getUrl();
    }

    // Simpan ke Sheet Pesanan
    const ss = SpreadsheetApp.getActiveSpreadsheet();
    const sheet = ss.getSheetByName(SHEET_PESANAN);

    sheet.appendRow([
      new Date(),          // A Tanggal
      data.nama,           // B Nama
      data.email,          // C Email
      data.instagram,      // D Instagram
      data.metode,         // E Metode
      data.produk,         // F Produk
      data.harga,          // G Harga
      data.deskripsi,      // H Deskripsi
      data.jumlah,         // I Jumlah
      "",                  // J Kode Kupon
      "Menunggu",          // K Status
      "",                  // L Tombol Approve
      buktiUrl             // M Bukti
    ]);

    const lastRow = sheet.getLastRow();
    if (lastRow) {
      pasangTombolApprove(lastRow);
    }

    return ContentService.createTextOutput(JSON.stringify({ status: "success" }))
      .setMimeType(ContentService.MimeType.JSON);

  } catch (err) {
    return ContentService.createTextOutput(JSON.stringify({ status: "error", message: err.message }))
      .setMimeType(ContentService.MimeType.JSON);
  }
}

/** ==========================

GET PRODUK

========================== */
function getProduk() {
  const sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(SHEET_PRODUK);
  const values = sheet.getDataRange().getValues();
  const headers = values.shift();
  return values.map(row => {
    let obj = {};
    headers.forEach((h, i) => obj[h] = row[i]);
    return obj;
  });
}

/** ==========================

PASANG TOMBOL APPROVE (Kolom L)

========================== */
function pasangTombolApprove(row) {
  if (!row) return; // antisipasi biar tidak null
  const sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(SHEET_PESANAN);
  const url = ScriptApp.getService().getUrl();
  const link = `${url}?action=approveKuponku&row=${row}`; // FIXED
  const rich = SpreadsheetApp.newRichTextValue()
    .setText("✅ Setujui")
    .setLinkUrl(link)
    .build();
  sheet.getRange(row, 12).setRichTextValue(rich); // Kolom L
}

function approvePesanan(rowIndex) {
  if (!rowIndex) {
    return ContentService.createTextOutput(JSON.stringify({ status: "error", message: "Row index kosong" }))
      .setMimeType(ContentService.MimeType.JSON);
  }

  const sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(SHEET_PESANAN);
  const namaPembeli = sheet.getRange(rowIndex, 2).getValue(); // Kolom B Nama
  const jumlah = parseInt(sheet.getRange(rowIndex, 9).getValue(), 10) || 1; // Kolom I Jumlah

  // Buat kode kupon
  const kuponList = [];
  for (let i = 0; i < jumlah; i++) {
    kuponList.push(generateKodeKupon());
  }

  // Update sheet
  sheet.getRange(rowIndex, 10).setValue(kuponList.join(", ")); // Kolom J
  sheet.getRange(rowIndex, 11).setValue("Disetujui"); // Kolom K
  sheet.getRange(rowIndex, 12).clearContent(); // Kolom L

  // Template HTML untuk PDF
  const htmlContent = `
<html>  
  <head>  
    <meta charset="utf-8">  
    <style>  
      body { font-family: Arial, sans-serif; text-align: center; padding: 24px; }  
      h2 { color: #333333; margin-bottom: 18px; }  
      .sub { margin-top:0; color:#555; font-size: 16px; }  
      .info { margin: 8px 0 4px; font-size: 16px; }  
      .kode-title { text-align: left; font-weight: bold; margin: 16px 10% 8px; width:80%; margin-left:10%; }  
      table { border-collapse: collapse; width: 80%; margin: auto; }  
      td { border: 1px solid #000; padding: 14px 8px; text-align: center; font-weight: 700; width: 33%; }  
      .icons { margin-top: 24px; font-size: 14px; }  
      .icons img { width: 20px; vertical-align: middle; margin-right: 6px; }  
      a { color: #1155cc; text-decoration: none; }  
      .footer-note { margin-top: 18px; color:#444; font-size:13px; }  
    </style>  
  </head>  
  <body>  
    <h2>🎉 KUPON UNDIAN 🎉</h2>  
    <p class="sub">Nama: <strong>${escapeHtml(namaPembeli)}</strong></p>  
    <p class="info">Jumlah Kupon: <strong>${jumlah}</strong></p>  
    <p class="kode-title">Kode Kupon Anda:</p>  
    <table>  
      ${(() => {  
        let rows = "";  
        for (let i = 0; i < kuponList.length; i += 3) {  
          rows += "<tr>";  
          for (let j = 0; j < 3; j++) {  
            const kode = kuponList[i + j] || "";  
            rows += `<td>${kode ? "• " + escapeHtml(kode) : ""}</td>`;  
          }  
          rows += "</tr>";  
        }  
        return rows;  
      })()}  
    </table>  

    <p class="footer-note">  
       Nantikan pengumuman pemenang di Instagram & website resmi kami  
    </p>  
    <p>📷 kupon_ku &nbsp;&nbsp; 🌐 kuponku.github.io/kupon/</p>  
  </body>  
</html>
`;

  try {
    const htmlBlob = Utilities.newBlob(htmlContent, "text/html", "kupon.html");
    const htmlFile = DriveApp.createFile(htmlBlob);

    const pdfBlob = htmlFile.getAs("application/pdf").setName(`Kupon - ${namaPembeli}.pdf`);  
    const pdfFile = DriveApp.createFile(pdfBlob);  

    pdfFile.setSharing(DriveApp.Access.ANYONE_WITH_LINK, DriveApp.Permission.VIEW);  

    try { htmlFile.setTrashed(true); } catch (e) { /* ignore */ }  

    const email = sheet.getRange(rowIndex, 3).getValue(); // Kolom C Email  
    if (email) {  
      MailApp.sendEmail({  
        to: email,  
        subject: "Kupon Undian",  
        htmlBody: `Halo ${escapeHtml(namaPembeli)},<br><br>Berikut lampiran kupon Anda dalam bentuk PDF.<br>Semoga beruntung! <br><br>Salam hangat dari,<br>Admin KuponKu 😊`,  
        attachments: [pdfFile.getBlob()]  
      });  
    }  

    return ContentService.createTextOutput(  
      JSON.stringify({ status: "approved", kupon: kuponList, pdfUrl: pdfFile.getUrl() })  
    ).setMimeType(ContentService.MimeType.JSON);

  } catch (err) {
    return ContentService.createTextOutput(
      JSON.stringify({ status: "approved", kupon: kuponList, error: err.toString() })
    ).setMimeType(ContentService.MimeType.JSON);
  }
}

/** ==========================

GENERATE KODE KUPON

========================== */
function generateKodeKupon() {
  const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
  let result = "";
  for (let i = 0; i < 8; i++) {
    result += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return result;
}

/** ==========================

Helper: escape HTML (sedikit aman)

========================== */
function escapeHtml(text) {
  if (text === null || text === undefined) return "";
  return String(text)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}