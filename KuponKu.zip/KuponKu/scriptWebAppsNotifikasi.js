const SHEET_NOTIFIKASI = "Notifikasi";

function doGet(e) {
  const action = e?.parameter?.action || "";
  if (action === "getNotifikasi") {
    return getNotifikasi();
  }
  return ContentService.createTextOutput(
    JSON.stringify({ status: "error", message: "Action tidak dikenali" })
  ).setMimeType(ContentService.MimeType.JSON);
}

function getNotifikasi() {
  try {
    const sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(SHEET_NOTIFIKASI);
    if (!sheet) throw new Error(`Sheet '${SHEET_NOTIFIKASI}' tidak ditemukan.`);

    const values = sheet.getDataRange().getValues();
    const headers = values.shift();

    const data = values
      .filter(row => row.some(cell => String(cell).trim() !== ""))
      .map(row => {
        let obj = {};
        headers.forEach((h, i) => {
          let key = h.toString().trim().toLowerCase();
          let val = row[i];

          // Format tanggal ke WIB
          if (key === "tanggal" && val) {
            let dateObj = val instanceof Date ? val : new Date(val);
            if (!isNaN(dateObj)) {
              // +7 jam dari UTC untuk WIB
              dateObj = new Date(dateObj.getTime() + (7 * 60 * 60 * 1000));
              val = Utilities.formatDate(dateObj, "Asia/Jakarta", "dd MMMM yyyy");
            }
          }

          if (typeof val === "string") val = val.trim();
          obj[key] = val || "";
        });

        // Jika gambar dari Google Drive tapi belum direct link, ubah jadi direct
        if (obj.gambar && obj.gambar.includes("drive.google.com") && !obj.gambar.includes("uc?id=")) {
          const idMatch = obj.gambar.match(/[-\w]{25,}/);
          if (idMatch) {
            obj.gambar = `https://drive.google.com/uc?id=${idMatch[0]}`;
          }
        }

        if (!obj.gambar) delete obj.gambar;

        return obj;
      });

    return ContentService.createTextOutput(JSON.stringify(data))
      .setMimeType(ContentService.MimeType.JSON);

  } catch (err) {
    return ContentService.createTextOutput(
      JSON.stringify({ status: "error", message: err.message })
    ).setMimeType(ContentService.MimeType.JSON);
  }
}